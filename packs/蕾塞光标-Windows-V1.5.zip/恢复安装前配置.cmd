@echo off
"%~dp0RezeCursor.exe" restore
if errorlevel 1 pause
