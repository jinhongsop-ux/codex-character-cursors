@echo off
"%~dp0RezeCursor.exe" check --quiet
pause
