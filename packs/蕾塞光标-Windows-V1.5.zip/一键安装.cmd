@echo off
"%~dp0RezeCursor.exe" install
if errorlevel 1 pause
