@echo off
"%~dp0RemCursor.exe" install
if errorlevel 1 pause
