@echo off
"%~dp0RemCursor.exe" restore
if errorlevel 1 pause
