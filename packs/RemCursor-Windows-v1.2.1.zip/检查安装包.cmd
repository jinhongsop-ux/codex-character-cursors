@echo off
"%~dp0RemCursor.exe" check --quiet
pause
