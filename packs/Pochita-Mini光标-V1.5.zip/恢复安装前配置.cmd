@echo off
"%~dp0PochitaCursor.exe" restore
if errorlevel 1 pause
