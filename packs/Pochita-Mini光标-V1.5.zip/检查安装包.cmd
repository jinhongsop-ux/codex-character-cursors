@echo off
"%~dp0PochitaCursor.exe" check
if errorlevel 1 pause
