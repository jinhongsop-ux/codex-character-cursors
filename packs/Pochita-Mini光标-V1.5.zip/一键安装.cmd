@echo off
"%~dp0PochitaCursor.exe" install
if errorlevel 1 pause
