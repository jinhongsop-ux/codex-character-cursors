@echo off
"%~dp0DeepseekCursor.exe" restore
if errorlevel 1 pause
