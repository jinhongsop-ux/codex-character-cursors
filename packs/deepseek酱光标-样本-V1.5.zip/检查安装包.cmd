@echo off
"%~dp0DeepseekCursor.exe" check
if errorlevel 1 pause
