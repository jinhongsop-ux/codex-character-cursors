@echo off
"%~dp0DeepseekCursor.exe" install
if errorlevel 1 pause
