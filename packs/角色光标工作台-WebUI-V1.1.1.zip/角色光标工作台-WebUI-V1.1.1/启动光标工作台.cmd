@echo off
start "" "%~dp0CursorStudio.exe"
